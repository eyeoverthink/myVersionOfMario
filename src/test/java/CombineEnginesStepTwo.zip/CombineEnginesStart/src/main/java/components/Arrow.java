package components;

public class Arrow extends Fireball{

    public Arrow(){

    }
}
