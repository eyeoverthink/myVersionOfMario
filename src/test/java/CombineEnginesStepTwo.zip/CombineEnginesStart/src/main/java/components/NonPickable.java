package components;

public class NonPickable extends Component {
}
