package components;

public class CharAI extends  TurtleAI {

    public CharAI(){

    }



    public static class Both extends Block{


        @Override
        void playerHit(PlayerController playerController) {

        }
    }

}


