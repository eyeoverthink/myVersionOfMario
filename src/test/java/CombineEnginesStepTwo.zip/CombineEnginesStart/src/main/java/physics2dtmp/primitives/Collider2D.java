package physics2dtmp.primitives;

import components.Component;
import org.joml.Vector2f;

public class Collider2D extends Component {
    protected Vector2f offset = new Vector2f();

    // TODO: IMPLEMENT THIS
    //public abstract float getInertiaTensor(float mass);
}
