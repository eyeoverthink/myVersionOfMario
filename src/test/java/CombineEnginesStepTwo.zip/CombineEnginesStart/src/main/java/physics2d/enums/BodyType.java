package physics2d.enums;

public enum BodyType {
    Static,
    Dynamic,
    Kinematic
}
